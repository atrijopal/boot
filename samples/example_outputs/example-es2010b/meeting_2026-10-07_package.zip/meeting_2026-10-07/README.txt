MEETING PACKAGE
File: ami_ES2010b_600s-900s.flac (example)
Date: 2026-10-07

Files in this package:
- meeting_2026-10-07_raw_transcript.txt: Raw transcript: the speech-to-text result before any refinement
- meeting_2026-10-07_raw_transcript.json: Raw transcript: the speech-to-text result before any refinement
- meeting_2026-10-07_refined_transcript.txt: Refined transcript: after terminology correction, with every change listed
- meeting_2026-10-07_refined_transcript.json: Refined transcript: after terminology correction, with every change listed
- meeting_2026-10-07_report.pdf: Meeting minutes and key decisions and action items, as a document
- meeting_2026-10-07_report.md: Meeting minutes and key decisions and action items, as a document
- meeting_2026-10-07_report.html: Meeting minutes and key decisions and action items, as a document
- meeting_2026-10-07_record.json: Meeting record in machine-readable form: raw and refined transcripts, minutes, decisions, action items
- meeting_2026-10-07_action_items.csv: Action items (owner and deadline are the word unspecified when the meeting did not state them)
- meeting_2026-10-07_email_summary.txt: A short summary ready to paste into an email

The human-readable report (PDF, Markdown, HTML) and the structured record (JSON) contain the same decisions and action items. A missing owner or deadline is written as unspecified; nothing is guessed.
